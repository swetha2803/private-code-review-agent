# Private Code Review Desk

Static, browser-only code review and security scanning page for sensitive source code.

## Privacy

- No backend.
- No CDN.
- No analytics.
- No network upload code path.
- Files are read with the browser `FileReader` API on the local machine.
- Reports are generated locally as JSON.
- Review packs are generated locally for security testing, unit testing, ISG testing, and dummy test data.
- Release gates, vendor evidence requests, manual review prompts, abuse cases, and Markdown reports are generated locally.

This tool can be hosted publicly because only the app shell is public. Reviewed code stays on the reviewer's device.

## Bank-Grade Review Model

For vendor banking code, use this app as your private review desk and run recognized scanners locally or inside your company network.

Recommended local scanner set:

- Semgrep for SAST.
- Gitleaks for secrets.
- OWASP Dependency-Check for vulnerable dependencies.
- SonarQube or Sonar Scanner when your organization has an approved SonarQube server.
- CodeQL, Checkmarx, Fortify, or Veracode only when approved by your bank/company process.

This repository includes `tools/run-security-review.ps1`, which runs installed local scanners and writes reports into `reports/`.

It also includes a local review agent:

```powershell
npm run agent -- "C:\path\to\vendor\source"
```

The agent recursively scans reviewable files, generates JSON and Markdown reports, creates evidence requests, produces security/unit/manual/abuse test packs, and exits with a non-zero code when critical or high findings exist.

It can also scan a ZIP file locally:

```powershell
npm run agent -- "C:\path\to\vendor-source.zip"
```

ZIP contents are extracted to a local temporary folder, scanned locally, and removed after the report is generated.

The browser dashboard can also review ZIP files locally using the bundled offline `lib/fflate.js` file. For very large repositories, the local agent is still recommended.

Scan an Azure DevOps Git repo locally:

```powershell
.\tools\scan-azure-repo.ps1 -RepoUrl "https://dev.azure.com/org/project/_git/repo" -Branch "develop"
```

Scan only one path using sparse checkout:

```powershell
.\tools\scan-azure-repo.ps1 -RepoUrl "https://dev.azure.com/org/project/_git/repo" -Branch "develop" -SparsePath "apps/mobile/src"
```

The repo is cloned into a local temporary folder, scanned locally, and deleted after report generation. Credentials are not stored by this tool; Git/Azure authentication is handled by your local Git credential manager.

Integration lead features:

- API inventory extracted from source patterns.
- Reviewed API report with risk focus for transfer, payment, beneficiary, login, OTP, profile, account, and statement APIs.
- Sanitized log analyzer for secrets, PII, stack traces, auth failures, and timeout/integration instability.
- Copy-ready vendor message, API team message, and log follow-up message.
- Meeting agenda/status summary in generated reports.
- Offline browser workbench for FS review, tracker row generation, CR readiness, EA architecture pack, ISG security validation, status note, issue fixing note, and Gamma-ready deck outline.
- EA architecture document generator with architecture pattern, data flow, dependencies, API summary, NFRs, deployment, and rollback sections for EA discussion and approval.
- ISG API/security validation with API inventory, auth/authZ, abuse controls, SAST/SCA, secret scan, evidence gaps, and security exceptions.
- Application flow explanation for uploaded/pasted/folder-scanned source.
- LLD and walkthrough validation for flow coverage, API contracts, timeout/retry, error handling, security controls, data handling, CI/CD, deployment, and claim-vs-evidence review.
- Main review type dropdown for Full code review, Code review using LLD, ISG security review, Log analyzer only, and EA architecture document.
- Code review using LLD compares uploaded code/APIs/auth/storage/logging/timeout behavior against pasted LLD notes and creates actionable code-vs-LLD findings.
- EA architecture review can locally read sanitized TXT/MD/DOCX/PPTX document samples, compare required architecture sections, and generate requested document changes without uploading the document.
- Review-flow profiles: Generic, Mobile, Backend, Frontend, Integration, and Full stack. Mobile adds focused checks for auth management, API connection config, web-client timeout config, PMD/code quality, build/publish pipeline, approved environment validation, and repo/access evidence.
- Local session save/load, session JSON export/import, and tracker CSV export for Excel/manual trackers.
- Offline review assistant that explains findings in plain English, suggests next actions, asks vendor/internal-team questions, and drafts a review clarification mail without using any external AI service.
- Technical and functional code explanations in simple English, plus strict review gates to separate blockers from normal improvement items.
- Redaction helper for sensitive text and issue register CSV export with owner/status/ETA/RCA/retest/closure fields.
- Printable report page for browser Print / Save as PDF.
- Optional Online Research Mode, disabled by default, that opens only generic OWASP/CWE/security reference links and never sends source code, logs, file names, sessions, or reports.

Do not paste real customer data, tokens, OTPs, passwords, production secrets, or unmasked banking identifiers into logs or reports.

Run the agent's own tests:

```powershell
npm test
```

Run the included dummy sample review:

```powershell
.\tools\test-sample-review.ps1
```

The sample intentionally produces blocking findings, API inventory, log findings, and report sections so you can verify the tool end to end without using real banking code.

Java sample:

```text
samples/java/EcommerceApp.java
```

Use it to test `.java` upload or paste-based review in the browser dashboard.

Example:

```powershell
.\tools\run-security-review.ps1 -SourcePath "C:\path\to\vendor\source"
```

Then open `index.html` and import the generated Semgrep, Gitleaks, or SARIF report.

The page also generates a review decision:

- `Reject` when critical findings exist.
- `Hold` when high findings exist.
- `Needs review` when medium findings are excessive.
- `Conditional` when only lower-risk findings exist.
- `No blocking findings` when the current result set is clean.

Use the generated Markdown report as a vendor review working paper. Do not treat a clean heuristic result as production approval without scanner evidence and manual review.

Optional custom Semgrep banking rules are in `scanner-config/semgrep-banking.yml`:

```powershell
semgrep scan --config .\scanner-config\semgrep-banking.yml --json --output .\reports\semgrep-banking.json "C:\path\to\vendor\source"
```

## Usage

Open `index.html` in a browser, then paste code or upload files/folders.

For offline installation behavior, serve it once from any static host or local HTTP server so the service worker can cache the files. After that, the page can continue to load without internet.

## Free Hosting Options

- GitHub Pages
- Cloudflare Pages
- Netlify
- Vercel static project

Do not add server-side upload, logging, analytics, or AI APIs if the reviewed code is banking or confidential.

## Limits

This is a private review desk, report viewer, and offline checklist generator. It intentionally does not claim to be SonarQube, Fortify, Checkmarx, or CodeQL. Those tools perform deeper analysis that a free static browser page cannot fully reproduce. Formal acceptance should come from your bank/company-approved SAST, SCA, secret scanning, dependency review, penetration testing, and secure architecture review process.
